# Quantix Labs — Dashboard

A full-featured SaaS analytics dashboard built with Next.js and Recharts.

## 🚀 Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel
vercel
```

### Option B — GitHub Import
1. Push this repo to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Click **Deploy** — no configuration needed

## 🛠 Local Development

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## 🏗 Build for Production

```bash
npm run build
npm start
```

## 🔑 Demo Credentials

| Field    | Value             |
|----------|-------------------|
| Email    | admin@quantix.io  |
| Password | admin123          |

## Tech Stack

- **Next.js 14** (App Router)
- **React 18**
- **Recharts** — data visualisations
- **CSS custom properties** — theming / dark-mode
- **localStorage** — session & theme persistence (client-side only)
